<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>K-TOUCH Waiter Dashboard</title>
  <link rel="stylesheet" href="assets/css/desktop.css">
</head>
<body data-layout="desktop">
<header class="topbar">
  <div class="brand"><span class="touch-mark">☝</span><b><i>K-TOUCH</i> POS</b></div>
  <div class="divider"></div><h1>Waiter Dashboard</h1>
  <nav><button data-action="refresh" class="outline">⟳ <span>Refresh</span></button><button data-action="logout" class="logout">⇥ <span>Log Out</span></button><button data-action="home" class="home">⌂ <span>Home</span></button></nav>
</header>

<main class="dashboard">
  <section class="left-column">
    <section class="profile-card">
      <div class="identity"><h2>JOHN MWANGI</h2><div><b>WT0045</b><span>SENIOR WAITER</span></div><p>Position: Floor Waiter&nbsp; · &nbsp;Main Bar</p><em><i></i> On Shift</em></div>
      <div class="profile-stats">
        <div class="shift-meta"><span>▣ <small>Counter</small><b>BAR</b></span><span>☀ <small>Shift</small><b>Day</b></span><span>▦ <b>29 Jun 2026</b></span></div>
        <div class="daily-meta"><span><small>TODAY'S SALES</small><b>KES 80,002</b></span><span><small>ORDERS SERVED</small><b>25</b></span><span><b>#2</b><small>TOP WAITER TODAY</small></span></div>
      </div>
    </section>

    <section class="card action-card">
      <header><h2>Available to Everyone</h2><p>Every waiter and barman</p></header>
      <div class="common-actions">
        <button class="featured green" data-action="place-order"><i>🛒</i><span><b>PLACE ORDER</b><small>Start a new order</small></span><em>›</em></button>
        <button class="featured teal" data-action="continue-bill"><i>≫</i><span><b>CONTINUE BILL</b><small>Resume an open bill</small></span><em>›</em></button>
        <button data-action="view-orders"><i>▤</i><span><b>VIEW ORDERS</b><small>Review today's orders</small></span><em>›</em></button>
        <button data-action="kpesa"><i>▯</i><span><b>K-PESA</b><small>Manage mobile payments</small></span><em>›</em></button>
        <button class="wide" data-action="change-pass"><i class="dark">♜</i><span><b>CHANGE PASS</b><small>Update your password</small></span><em>›</em></button>
      </div>
    </section>

    <section class="card role-card">
      <header><div><h2>Role Actions</h2><p>Shown according to staff position</p></div><div class="role-tabs"><button class="active">WAITER</button><button>BARMAN</button></div></header>
      <div class="role-actions">
        <button class="clear" data-action="clear-bill"><i>▰</i><span><b>CLEAR BILL</b><small>Settle pending payments</small></span><em>›</em></button>
        <button class="returns" data-action="returns"><i>↩</i><span><b>RETURNS</b><small>Request or review returns</small></span><em>›</em></button>
        <button class="stock" data-action="stock"><i>◆</i><span><b>STOCK</b><small>View counter stock</small></span><em>›</em></button>
        <button class="danger" data-action="close-counter"><i>⏻</i><span><b>CLOSE COUNTER</b><small>End the current counter shift</small></span><em>›</em></button>
      </div>
    </section>
  </section>

  <aside class="right-column">
    <section class="card approval-card"><header><h2>▲ &nbsp; Needs Approval</h2></header><div class="approval-list">
      <button data-action="returns"><i>↩</i><span>Returns not approved</span><strong>2</strong><b>KES 1,150</b><em>REVIEW</em></button>
      <button data-action="mpesa-approval"><i>▯</i><span>M-Pesa claimed<br>not approved</span><strong>0</strong><b>KES 0</b><em>REVIEW</em></button>
      <button data-action="void-approval"><i>⊘</i><span>Voided bills<br>not approved</span><strong>0</strong><b>KES 0</b><em>REVIEW</em></button>
    </div></section>

    <section class="wallet-card"><h2>My Token Wallet</h2><div class="wallet-stats"><i>●</i><span><small>Balance</small><b>KES 768.00</b></span><span><small>This Month</small><b>KES -14.50</b></span><span><small>Today</small><b>KES -14.50</b></span></div><button data-action="claim-tokens">CLAIM TOKENS &nbsp; →</button></section>

    <section class="card orders-card"><header><h2>Recent Orders</h2><button data-action="view-orders">View All</button></header><table><thead><tr><th>Bill No.</th><th>Time</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody id="orders">
      <tr><td>▥ &nbsp; Bill #1201</td><td>00:52</td><td>KES 1,201</td><td><span class="pending">Pending</span></td><td><button data-action="view-order" data-id="1201">VIEW</button></td></tr>
      <tr><td>▥ &nbsp; Bill #1200</td><td>00:28</td><td>KES 10,701</td><td><span class="pending">Pending</span></td><td><button data-action="view-order" data-id="1200">VIEW</button></td></tr>
      <tr><td>▥ &nbsp; Bill #1199</td><td>Yesterday</td><td>KES 2,700</td><td><span class="pending">Pending</span></td><td><button data-action="view-order" data-id="1199">VIEW</button></td></tr>
      <tr><td>▥ &nbsp; Bill #1198</td><td>Yesterday</td><td>KES 4,250</td><td><span class="paid">Paid</span></td><td><button data-action="view-order" data-id="1198">VIEW</button></td></tr>
      <tr><td>▥ &nbsp; Bill #1197</td><td>Yesterday</td><td>KES 8,600</td><td><span class="pending">Pending</span></td><td><button data-action="view-order" data-id="1197">VIEW</button></td></tr>
    </tbody></table></section>
  </aside>
</main>
<script src="assets/js/dashboard.js"></script>
</body></html>
