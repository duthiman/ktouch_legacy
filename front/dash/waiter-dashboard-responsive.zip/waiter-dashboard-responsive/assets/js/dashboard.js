(function(){
  'use strict';
  const orderData=[
    {icon:'⚑',name:'Table 12',time:'10 min ago',amount:'KES 7,500',status:'PENDING'},
    {icon:'♛',name:'VIP Lounge',time:'25 min ago',amount:'KES 14,000',status:'PAID'},
    {icon:'⚑',name:'Table 08',time:'40 min ago',amount:'KES 6,200',status:'PAID'},
    {icon:'☂',name:'Terrace 5',time:'1 hr ago',amount:'KES 3,800',status:'PENDING'},
    {icon:'♙',name:'Walk-in Customer',time:'1 hr ago',amount:'KES 1,200',status:'PAID'}
  ];
  const orders=document.getElementById('orders');
  if(orders && document.body.dataset.layout==='mobile') orders.innerHTML=orderData.slice(0,3).map(o=>`<button class="order-row" data-action="open-order"><i>${o.icon}</i><span><b>${o.name}</b><small>${o.time}</small></span><strong>${o.amount}</strong><em class="${o.status.toLowerCase()}">${o.status}</em><b>›</b></button>`).join('');
  const refresh=document.getElementById('refreshBtn');
  if(refresh) refresh.addEventListener('click',()=>{refresh.textContent='✓ UPDATED';setTimeout(()=>refresh.textContent='↻ REFRESH',1200);});
  document.addEventListener('click',function(e){const btn=e.target.closest('[data-action]');if(!btn)return;const action=btn.dataset.action;document.dispatchEvent(new CustomEvent('ktouch:dashboard-action',{detail:{action,button:btn}}));if(!window.KTouchDashboardRoutes || !window.KTouchDashboardRoutes[action])return;window.location.href=window.KTouchDashboardRoutes[action];});
  const desktop=matchMedia('(min-width:761px)');
  if(desktop.addEventListener) desktop.addEventListener('change',e=>{const current=document.body.dataset.layout;if(e.matches&&current==='mobile')location.replace('desktop.php'+location.search);if(!e.matches&&current==='desktop')location.replace('mobile.php'+location.search);});
})();
