<?php
include('../clude/head.php');
if (!isset($_SESSION['user_id']) || (int) $_SESSION['user_id'] === 0) {
    header('Location: ../log_out.php');
    exit;
}
?>
<link rel="stylesheet" href="assets/css/kwedia.css?v=<?php echo filemtime(__DIR__ . '/assets/css/kwedia.css'); ?>">
<body id="whole" class="kw-body" data-layout="desktop">
<div id="page-container" class="page-without-sidebar page-header-fixed kw-page">
  <main class="kw-desktop-app">
    <header class="kw-main-header">
      <div class="kw-user-summary">
        <span class="kw-user-icon" aria-hidden="true">◎</span>
        <div><strong id="kw-account-name">KTOUCH_ADMIN</strong><span>Counter: <b id="kw-counter-name">BAR</b></span></div>
      </div>
      <div class="kw-header-bill"><small>Bill No.</small><strong id="kw-sale-id">0</strong></div>
    </header>

    <section class="kw-workspace">
      <aside class="kw-card kw-category-panel">
        <h2><span aria-hidden="true">♙</span> Categories</h2>
        <div id="kw-categories-desktop" class="kw-category-list"></div>
      </aside>

      <section class="kw-card kw-catalog-panel">
        <div id="sub_cat" class="kw-subcategories"></div>
        <div class="kw-panel-heading">
          <div><h1>Menu</h1><span id="kw-menu-count">Items</span></div>
          <label class="kw-search"><span aria-hidden="true">⌕</span><input id="kw-menu-search" type="search" placeholder="Search menu items…" autocomplete="off"></label>
        </div>
        <div id="menu" class="kw-menu-grid"></div>
      </section>

      <aside class="kw-card kw-order-panel">
        <div class="kw-order-title">
          <span class="kw-receipt-icon" aria-hidden="true">▤</span>
          <div><strong><span id="kw-order-account-name">KTOUCH_ADMIN</span> · <span id="kw-order-counter-name">BAR</span></strong><span>Bill #<b id="kw-order-sale-id">0</b></span></div>
        </div>
        <div class="kw-order-tools">
          <button onclick="location.reload();" class="kw-tool-btn" type="button"><span>↻</span> Refresh</button>
          <div class="kw-tool-btn kw-mode-tool">
            <span>Touch Mode</span>
            <label class="kw-switch"><input type="checkbox" id="deci_mode_desktop" class="deci-mode-switch" checked><i></i><b id="deci_mode_text_desktop">On</b></label>
          </div>
        </div>
        <div id="screen" class="kw-order-screen"></div>
        <div class="kw-order-total" id="kw-desktop-total-strip"><span><b id="kw-desktop-line-count">0</b> line items</span><span>Total <strong>KES <b id="kw-desktop-total">0</b></strong></span></div>
        <div class="kw-order-actions">
          <button onclick="openCloseCurrentCounterModal()" class="kw-action kw-close" type="button">Close Order</button>
          <button onclick="openOpenBillModeModal()" class="kw-action kw-open" type="button">Open Order</button>
          <button data-toggle="modal" data-target="#modal" class="kw-action kw-cancel cancel-order-btn" id="cancel" type="button" style="display:none">Cancel</button>
        </div>
      </aside>
    </section>
  </main>

  <div id="modal" class="modal" tabindex="-1"><div class="modal-dialog" id="load"></div></div>
</div>
<script src="../../assets/plugins/jquery/jquery-3.2.1.min.js"></script>
<script src="../../assets/plugins/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<script src="kwedia.js"></script>
<script src="js.js?v=<?php echo filemtime(__DIR__ . '/js.js'); ?>"></script>
<script src="assets/js/kwedia-layout.js?v=<?php echo filemtime(__DIR__ . '/assets/js/kwedia-layout.js'); ?>"></script>
</body>
</html>
