(function (window, document) {
  'use strict';

  function all(selector) { return Array.prototype.slice.call(document.querySelectorAll(selector)); }
  function text(id, value) { var node = document.getElementById(id); if (node && value !== undefined && value !== null) node.textContent = value; }
  function number(value) { var n = parseFloat(String(value || 0).replace(/,/g, '')); return isNaN(n) ? 0 : n; }

  function syncMode(source) {
    all('.deci-mode-switch').forEach(function (control) {
      if (control !== source) control.checked = source.checked;
    });
    text('deci_mode_text_desktop', source.checked ? 'On' : 'Off');
    text('deci_mode_text_mobile', source.checked ? 'On' : 'Off');
    document.body.classList.toggle('kw-touch-mode', source.checked);
    document.dispatchEvent(new CustomEvent('kwedia:modechange', { detail: { touchMode: source.checked } }));
  }

  function openCart(open) {
    var drawer = document.getElementById('kw-cart-drawer');
    if (!drawer) return;
    drawer.classList.toggle('is-open', open);
    drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.style.overflow = open ? 'hidden' : '';
  }

  function filterMenu(term) {
    term = String(term || '').trim().toLowerCase();
    all('#menu > *, #menu_mobile > *').forEach(function (item) {
      item.style.display = !term || item.textContent.toLowerCase().indexOf(term) !== -1 ? '' : 'none';
    });
  }

  function mirrorIdentity() {
    var account = document.getElementById('kw-account-name') || document.getElementById('kw-account-name-mobile');
    var counter = document.getElementById('kw-counter-name') || document.getElementById('kw-counter-name-mobile');
    var sale = document.getElementById('kw-sale-id') || document.getElementById('kw-sale-id-mobile');
    if (account) ['kw-account-name-mobile','kw-order-account-name','kw-cart-account-name'].forEach(function(id){ text(id, account.textContent); });
    if (counter) ['kw-counter-name-mobile','kw-order-counter-name','kw-cart-counter-name'].forEach(function(id){ text(id, counter.textContent); });
    if (sale) ['kw-sale-id-mobile','kw-order-sale-id','kw-cart-sale-id'].forEach(function(id){ text(id, sale.textContent); });
  }

  window.KwediaLayout = {
    setCartSummary: function (count, total) {
      text('kw-cart-count', count); text('kw-cart-count-label', count); text('kw-cart-total', number(total).toLocaleString());
      text('kw-desktop-line-count', count); text('kw-desktop-total', number(total).toLocaleString());
    },
    syncIdentity: mirrorIdentity,
    openCart: function () { openCart(true); },
    closeCart: function () { openCart(false); }
  };

  document.addEventListener('DOMContentLoaded', function () {
    all('.deci-mode-switch').forEach(function (control) { control.addEventListener('change', function () { syncMode(control); }); });
    var firstMode = document.querySelector('.deci-mode-switch'); if (firstMode) syncMode(firstMode);
    var toggle = document.getElementById('kw-cart-toggle'); if (toggle) toggle.addEventListener('click', function () { openCart(true); });
    var close = document.getElementById('kw-cart-close'); if (close) close.addEventListener('click', function () { openCart(false); });
    all('[data-close-cart]').forEach(function (node) { node.addEventListener('click', function () { openCart(false); }); });
    var search = document.getElementById('kw-menu-search'); if (search) search.addEventListener('input', function () { filterMenu(search.value); });
    var mobileSearch = document.querySelector('#kw-mobile-search input'); if (mobileSearch) mobileSearch.addEventListener('input', function () { filterMenu(mobileSearch.value); });
    var searchToggle = document.getElementById('kw-mobile-search-toggle'); if (searchToggle) searchToggle.addEventListener('click', function () { var box=document.getElementById('kw-mobile-search'); box.classList.toggle('is-open'); if(box.classList.contains('is-open')) box.querySelector('input').focus(); });
    mirrorIdentity();
    setTimeout(mirrorIdentity, 700);
  });
}(window, document));
