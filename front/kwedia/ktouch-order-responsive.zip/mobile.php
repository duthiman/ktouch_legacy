<?php
include('../clude/head.php');
if (!isset($_SESSION['user_id']) || (int) $_SESSION['user_id'] === 0) {
    header('Location: ../log_out.php');
    exit;
}
?>
<link rel="stylesheet" href="assets/css/kwedia.css?v=<?php echo filemtime(__DIR__ . '/assets/css/kwedia.css'); ?>">
<body id="whole" class="kw-body" data-layout="mobile">
<div id="page-container" class="page-without-sidebar page-header-fixed kw-page">
  <main class="kw-mobile-app">
    <header class="kw-mobile-header">
      <div class="kw-mobile-user"><span class="kw-user-icon">◎</span><div><strong id="kw-account-name-mobile">KTOUCH_ADMIN</strong><span>Counter: <b id="kw-counter-name-mobile">BAR</b></span></div></div>
      <div class="kw-header-bill"><small>Bill No.</small><strong id="kw-sale-id-mobile">0</strong></div>
    </header>

    <section class="kw-card kw-mobile-categories">
      <div class="kw-section-heading"><h1>Categories</h1><small>Swipe ↔</small></div>
      <div id="kw-categories-mobile" class="kw-category-scroll"></div>
      <div id="sub_cat_mobile" class="kw-subcategories kw-mobile-subcategories"></div>
    </section>

    <section class="kw-card kw-mobile-menu">
      <div class="kw-section-heading"><div><h1>Menu</h1><small id="kw-mobile-menu-count">Items</small></div><button id="kw-mobile-search-toggle" class="kw-icon-button" type="button" aria-label="Search">⌕</button></div>
      <label class="kw-mobile-search" id="kw-mobile-search"><input type="search" placeholder="Search menu items…"></label>
      <div id="menu_mobile" class="kw-menu-grid"></div>
    </section>
  </main>

  <button type="button" class="kw-cart-bar" id="kw-cart-toggle">
    <span class="kw-cart-icon">▣<b id="kw-cart-count">0</b></span>
    <span><strong id="kw-cart-count-label">0</strong> items</span>
    <span class="kw-cart-total">KES <strong id="kw-cart-total">0</strong></span>
    <span class="kw-view-cart">View Cart ›</span>
  </button>

  <div class="kw-cart-drawer" id="kw-cart-drawer" aria-hidden="true">
    <div class="kw-drawer-backdrop" data-close-cart></div>
    <section class="kw-card kw-mobile-order">
      <div class="kw-order-title"><span class="kw-receipt-icon">▤</span><div><strong id="kw-cart-account-name">KTOUCH_ADMIN</strong><span><b id="kw-cart-counter-name">BAR</b> · Bill #<b id="kw-cart-sale-id">0</b></span></div><button id="kw-cart-close" class="kw-cart-close" type="button">×</button></div>
      <div class="kw-order-tools">
        <button onclick="location.reload();" class="kw-tool-btn" type="button">↻ Refresh</button>
        <div class="kw-tool-btn kw-mode-tool"><span>Touch Mode</span><label class="kw-switch"><input type="checkbox" id="deci_mode_mobile" class="deci-mode-switch" checked><i></i><b id="deci_mode_text_mobile">On</b></label></div>
      </div>
      <div id="screen_mobile" class="kw-order-screen"></div>
      <div class="kw-order-actions">
        <button onclick="openCloseCurrentCounterModal()" class="kw-action kw-close" type="button">Close Order</button>
        <button onclick="openOpenBillModeModal()" class="kw-action kw-open" type="button">Open Order</button>
        <button data-toggle="modal" data-target="#modal" class="kw-action kw-cancel cancel-order-btn" type="button" style="display:none">Cancel</button>
      </div>
    </section>
  </div>

  <div id="modal" class="modal" tabindex="-1"><div class="modal-dialog" id="load"></div></div>
</div>
<script src="../../assets/plugins/jquery/jquery-3.2.1.min.js"></script>
<script src="../../assets/plugins/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<script src="kwedia.js"></script>
<script src="js.js?v=<?php echo filemtime(__DIR__ . '/js.js'); ?>"></script>
<script src="assets/js/kwedia-layout.js?v=<?php echo filemtime(__DIR__ . '/assets/js/kwedia-layout.js'); ?>"></script>
</body>
</html>
