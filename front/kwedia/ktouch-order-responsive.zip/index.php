<?php
session_start();
if (!isset($_SESSION['user_id']) || (int) $_SESSION['user_id'] === 0) {
    header('Location: ../log_out.php');
    exit;
}

$forced = isset($_GET['layout']) ? strtolower((string) $_GET['layout']) : '';
if ($forced === 'mobile') {
    header('Location: mobile.php');
    exit;
}
if ($forced === 'desktop') {
    header('Location: desktop.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>K-TOUCH Order</title>
  <style>html,body{height:100%;margin:0;background:#171b1d;color:#fff;font:600 16px Arial,sans-serif;display:grid;place-items:center}.loader{display:flex;gap:12px;align-items:center}.dot{width:14px;height:14px;border-radius:50%;background:#f36b0a;animation:pulse .8s infinite alternate}@keyframes pulse{to{opacity:.35;transform:scale(.72)}}</style>
</head>
<body>
  <div class="loader"><span class="dot"></span>Loading K-TOUCH POS…</div>
  <script>
    (function () {
      var mobile = window.matchMedia('(max-width: 767px)').matches;
      window.location.replace(mobile ? 'mobile.php' : 'desktop.php');
    }());
  </script>
</body>
</html>
